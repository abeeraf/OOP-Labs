#include "Person.h"
Person::Person()
{

}
Person::Person(string n, string a)
{
	name=n;
	address=a;
}
