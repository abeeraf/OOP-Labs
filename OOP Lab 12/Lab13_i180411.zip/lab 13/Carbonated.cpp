#include "Carbonated.h"

Carbonated::Carbonated()
{

}
Carbonated::Carbonated(string a, string b, string c, int d, int e,  int f):Water(b,c,d,e,f)
{
	type=a;
}
void Carbonated::display()
{

}
