
template<class T>
class Calculator {
public:
	T add(T x, T y)
	{
		return x+y;
	}
	T sub(T x, T y)
	{
		return x-y;
	}
	T mul(T x, T y)
	{
		return x*y;
	}
	T div(T x, T y)
	{
		return x/y;
	}
};
