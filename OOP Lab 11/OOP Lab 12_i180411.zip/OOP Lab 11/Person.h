#ifndef Person_h
#define Person_h
#include <cstring>
#include <iostream>
using namespace std; 

class Person{

string Name;
string Address;

public:
Person();
Person(string nam,string add);
};
#endif
