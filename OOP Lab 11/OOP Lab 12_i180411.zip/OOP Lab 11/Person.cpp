#include "Person.h"

Person::Person()
{

}
Person::Person(string nam,string add)
{
	Name=nam;
	Address=add;
}
