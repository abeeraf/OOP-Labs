//Task1

void StudentCardArrayIntialize(StudentCard arr[], int s){// Write you code here of Task1- part b}
void PrintStudentCard(StudentCard s) {// Write you code here of Task1- part c}
//Task2
long timeToSeconds(CustomTime t1) {// Write you code here of Task2- part b}
CustomTime SecondsToTime(long t) {// Write you code here of Task2- part c}
CustomTime AddTimes(CustomTime t1, CustomTime t2) { // Write you code here of Task2- part d}
CustomTime* MakeNewTime() {// Write you code here of Task2- part e}
void IntilaizeTime(CustomTime* & p, long totalSec) {// Write you code here of Task2- part f}
CustomTime* MakeArrayOfTimes(int s) {// Write you code here of Task2- part g}
void IntilaizeTimeArray(CustomTime* &p, int hours[], int mins[], int sec[],int s) {// Write you code here of Task2- part h}

//Task3
void IntializeFraction(Fraction &f, int deNom, int Nom) {// Write you code here}
Fraction AddFractions(Fraction f1, Fraction f2){// Write you code here}
Fraction MultiplyFractions(Fraction f1, Fraction f2){// Write you code here}
Fraction SubtractFractions(Fraction f1, Fraction f2){// Write you code here}
Fraction DivideFractions(Fraction f1, Fraction f2){// Write you code here}

//Task4
void Initialize() {//Write you code here}
void Destroy() {//Write you code here}
bool setRollNo(int r){//Write you code here}
int getRollNo(){//Write you code here}
bool setName(char* n){//Write you code here}
char* getName(){//Write you code here}
bool setCity(string c){//Write you code here }
string getCity(){//Write you code here}
bool setPhone(string c){//Write you code here }
string getPhone(){//Write you code here }
void SetStudentArray(Student arr[], int size, char* names[], string cities[], string phones[]) {//Write you code here}
void GetStudentArray(Student arr[], int size) {//Write you code here}

//Task5
void setBasicPay(long bp){//Write you code here}
long getBasicPay(){//Write you code here}
void setEmpNo(int e){//Write you code here}
int getEmpNo(){//Write you code here}
void calculateHouseRent(){//Write you code here}
void calculateMedicalAllowance(){//Write you code here}
void calculateConveyanceAllowance(){//Write you code here}
void calculateNetPay(){//Write you code here}
long gethouseRent(){//Write you code here}
long getMedicalAllowance(){//Write you code here}
long getConveyanceAllowance(){//Write you code here}
long getNetPay(){//Write you code here}
void Swap(Employee & emp1, Employee & emp2){//Write you code here}

//Task6
void Initilaize(string dp, string an, int acountTypeId, string accountTypeName, long
balance){//Write you code here}
bool depositAmount(long amountToDeposite){//Write you code here}
bool withdrawAmount(long amountToWithdraw){//Write you code here}
long getAmount(){//Write you code here}


//Task7
int GetCreditHoursCount(SemesterRegistration sr){//Write you code here}
bool FindCourseInSemesterRegistration(SemesterRegistration sr,String Coursecode ){//Write you code here}


//FOr TASK 8 and 9 use the defined member functions in lab task pdf.


